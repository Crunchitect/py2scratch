<img align="center" src="./readme-assets/scratch.png">
<h1 align="center">py2scratch</h1>

<p align="center">A module that converts python into scratch projects<p>

## Installation

Just `pip install` this, Depencies are currently only `pillow`!

```cmd
pip install py2scratch
```
